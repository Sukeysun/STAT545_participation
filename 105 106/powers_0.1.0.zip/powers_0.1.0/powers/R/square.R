#' @title Sqaure the input
#' @param x Vector of numerics
#' @return The vecotr x, squared.
#' @export
square <- function(x) x^2
