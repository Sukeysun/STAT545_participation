
pow <- function(x,p) x^p
