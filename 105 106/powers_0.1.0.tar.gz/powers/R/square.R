#' @title Sqaure the input
#' @param x Vector of numerics
#' @return The vecotr x, squared.
#' @rdname common_doc
#' @export
square <- function(x) pow(x,2)
